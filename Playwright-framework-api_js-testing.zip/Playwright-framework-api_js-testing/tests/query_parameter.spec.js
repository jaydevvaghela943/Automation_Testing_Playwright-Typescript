const { test, expect}  =  require("@playwright/test");
const bookingAPiBody = require("../test-data/post_dynamic_request.json");
import { stringFormat } from "../utils/common";
import { faker } from "@faker-js/faker";
const { DateTime } = require("luxon");


//Install package
// : npm i @faker-js/faker
// : npm i luxon

/*
API TESTING FlOW
=====================
1. Load Playwright module
2. Write a test
3. Create POST API request
4. Validate status code
5. Validate json api response
6. Validate nested json Object
*/

//Write a test
test("Query Parameter",async({request})=>{
    const firstName = faker.person.firstName();
    const lastName = faker.person.lastName();
    const totalPrice = faker.number.int(1000);
    const checkInDate = DateTime.now().toFormat("yyyy-MM-dd");
    const checkOutDate = DateTime.now().plus({ day: 5 }).toFormat("yyyy-MM-dd");

    var updatedRequestBody = stringFormat(
        JSON.stringify(bookingAPiBody),
        firstName,
        lastName,
        "apple"
    );

    const postApiResponse = await request.post("/booking", {
    data: JSON.parse(updatedRequestBody),
  });
    
    //Validate status code
    await expect(postApiResponse.ok()).toBeTruthy();
    await expect(postApiResponse.status()).toBe(200);

    
    const postAPiObject = await postApiResponse.json();

    const bookingId = postAPiObject.bookingid;

    //Validate json api response
    await expect(postAPiObject.booking).toHaveProperty("firstname",firstName);
    await expect(postAPiObject.booking).toHaveProperty("lastname",lastName);

    //Validate nested json Object
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkin",'2026-01-10');
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkout",'2026-01-11');
 

    console.log(postAPiObject);
    //Call Get API
    const getApiResponse = await request.get('/booking',{
        params:{
            "firstname":"Filiberto"
        }
    });

    // Validate Status code
    expect(getApiResponse.ok()).toBeTruthy();
    expect(getApiResponse.status()).toBe(200);

    console.log("get-=======",await getApiResponse.json());
});