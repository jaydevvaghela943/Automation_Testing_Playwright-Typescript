const { test, expect}  =  require("@playwright/test");
const postAPiBody = require("../test-data/post_request.json");
const putRequest = require("../test-data/put_request.json");
const tokenRequest = require("../test-data/token_request.json");
import { stringFormat } from "../utils/common";
import { faker } from "@faker-js/faker";
const { DateTime } = require("luxon");


//Install package
// : npm i @faker-js/faker
// : npm i luxon

/*
API TESTING FlOW
=====================
1. Load Playwright module
2. Write a test
3. Create POST API request
4. Validate status code
5. Validate json api response
6. Validate nested json Object
*/

//Write a test
test("Query Parameter",async({request})=>{
    
    const postApiResponse = await request.post("/booking", {
    data: postAPiBody,
  });
    
    //Validate status code
    await expect(postApiResponse.ok()).toBeTruthy();
    await expect(postApiResponse.status()).toBe(200);

    
    const postAPiObject = await postApiResponse.json();
    const bookingId = postAPiObject.bookingid;

    //Call Get API
    const getApiResponse = await request.get('/booking',{
        params:{
            firstname: "testers talk playwright",
            lastname: "testers talk api testing",
        }
    });

    // Validate Status code
    expect(getApiResponse.ok()).toBeTruthy();
    expect(getApiResponse.status()).toBe(200);

    console.log("get-=======",await getApiResponse.json());

    // generate token
  const tokenAPIResponse = await request.post("/auth", {
    data: tokenRequest,
  });
  expect(tokenAPIResponse.ok()).toBeTruthy();
  expect(tokenAPIResponse.status()).toBe(200);


   console.log(await tokenAPIResponse.json());
  const tokenResponseBody = await tokenAPIResponse.json();
  const tokenNo = tokenResponseBody.token;

  // update booking details
  const putAPIResponse = await request.put(`/booking/${bookingId}`, {
    headers: {
      "Content-Type": "application/json",
      "Cookie": `token=${tokenNo}`,
    },
    data: putRequest,
  });

  console.log(await putAPIResponse.json());
  expect(putAPIResponse.ok()).toBeTruthy();
  expect(putAPIResponse.status()).toBe(200);

  // DELETE api request
  // partial update booking details
  const deleteAPIResponse = await request.delete(`/booking/${bookingId}`, {
    headers: {
      "Content-Type": "application/json",
      "Cookie": `token=${tokenNo}`,
    },
  });
  expect(deleteAPIResponse.status()).toBe(201);
  expect(deleteAPIResponse.statusText()).toBe("Created");


});