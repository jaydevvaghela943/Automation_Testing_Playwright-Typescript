const { test, expect } = require("@playwright/test");

/*
API TESTING FlOW
=====================
1. Load Playwright module
2. Write a test
3. Create POST API request
4. Validate status code
5. Validate json api response
6. Validate nested json Object
*/

test("GET API Request",async({request})=>{

    //Navigate to 
    const getAPIResponse = await request.get("/booking/1", {});

    // validate status code
    console.log("API Response==>",getAPIResponse.json());

})