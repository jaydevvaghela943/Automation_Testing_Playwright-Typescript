const { test, expect}  =  require("@playwright/test");
import {faker} from '@faker-js/faker'
const { DateTime } = require('luxon');


//Install package
// : npm i @faker-js/faker
// : npm i luxon

/*
API TESTING FlOW
=====================
1. Load Playwright module
2. Write a test
3. Create POST API request
4. Validate status code
5. Validate json api response
6. Validate nested json Object
*/

//Write a test
test("POST API",async({request})=>{
    //Create POST API request
    const firstName = faker.person.firstName();
    const lastName  = faker.person.lastName();
    const amount    = faker.number.int(1250);

    const checkIndate   = DateTime.now().toFormat('yyyy-MM-dd');
    const checkOutdate  = DateTime.now().plus({day:5}).toFormat('yyyy-MM-dd');

    const postApiResponse = await request.post('/booking', {
        data: {
            "firstname": firstName,
            "lastname": lastName,
            "totalprice": amount,
            "depositpaid": true,
            "bookingdates": {
                "checkin": checkIndate,
                "checkout": checkOutdate
            },
            "additionalneeds": "super bowls"
        }
    });
    
    //Validate status code
    await expect(postApiResponse.ok()).toBeTruthy();
    await expect(postApiResponse.status()).toBe(200);

    
    const postAPiObject = await postApiResponse.json();

    //Validate json api response
    await expect(postAPiObject.booking).toHaveProperty("firstname",firstName);
    await expect(postAPiObject.booking).toHaveProperty("lastname",lastName);

    //Validate nested json Object
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkin",checkIndate);
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkout",checkOutdate);


    console.log(postAPiObject);
});