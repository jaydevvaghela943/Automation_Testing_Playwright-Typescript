const { test, expect, request } = require("@playwright/test");
/*
API TESTING FlOW
=====================
1. Load Playwright module
2. Write a test
3. Create POST API request
4. Validate status code
5. Validate json api response
6. Validate nested json Object
*/

//Write a test
test("POST API",async({request})=>{
    //Create POST API request
    const postApiResponse = await request.post('/booking',{
        data:{
            "firstname": "Jay",
            "lastname": "Vaghela",
            "totalprice": 1500,
            "depositpaid": true,
            "bookingdates": {
                "checkin": "2026-01-10",
                "checkout": "2026-01-11"
            },
            "additionalneeds": "super bowls"
        }
    });

    //Validate status code
    await expect(postApiResponse.ok()).toBeTruthy();
    await expect(postApiResponse.status()).toBe(200);

    
    const postAPiObject = await postApiResponse.json();

    //Validate json api response
    await expect(postAPiObject.booking).toHaveProperty("firstname","Jay");
    await expect(postAPiObject.booking).toHaveProperty("lastname","Vaghela");

    //Validate nested json Object
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkin","2026-01-10");
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkout","2026-01-11");


    console.log(postAPiObject);
});