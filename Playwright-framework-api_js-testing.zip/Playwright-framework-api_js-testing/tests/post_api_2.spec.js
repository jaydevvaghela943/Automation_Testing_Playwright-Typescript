const { test, expect}  =  require("@playwright/test");
const post_data         = require('../test-data/post_request.json');

/*
API TESTING FlOW
=====================
1. Load Playwright module
2. Write a test
3. Create POST API request
4. Validate status code
5. Validate json api response
6. Validate nested json Object
*/

//Write a test
test("POST API",async({request})=>{
    //Create POST API request
    const postApiResponse = await request.post('/booking', {
        data: post_data
    });

    //Validate status code : Not required await
    expect(postApiResponse.ok()).toBeTruthy();
    expect(postApiResponse.status()).toBe(200);

    
    const postAPiObject = await postApiResponse.json();

    //Validate json api response
    await expect(postAPiObject.booking).toHaveProperty("firstname","Jay");
    await expect(postAPiObject.booking).toHaveProperty("lastname","Vaghela");

    //Validate nested json Object
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkin","2026-01-10");
    await expect(postAPiObject.booking.bookingdates).toHaveProperty("checkout","2026-01-11");


    console.log(postAPiObject);
});